<?php
/**
 * Created by PhpStorm.
 * User: bunja
 * Date: 8/2/17
 * Time: 2:48 PM
 */

$msg = "";
$messageFailed = "";
$successful = "";
$validatePhone = "";
if (isset($_POST['submit'])) {
    // if (!preg_match('/^\(?\+?([0-9]{1,4})\)?[-\. ]?(\d{3})[-\. ]?([0-9]{7})$/', trim($_POST['phone']))) {
    if(!is_numeric($_POST['phone'])){
        $validatePhone = "Please enter a valid phone number";
    } else {
        $firstname = $_POST['firstname'];
        $lastname = $_POST['lastname'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
	    $subject = $_POST['subject'];
        $message = $_POST['message'];
        $msg = "Phone: " . $phone . "\n". "Name: " . $firstname . " " . $lastname . "\n"."\n" . $message;
        // replace the email with the email you will create for ITCA
        $sent = mail("bunjabarra100@gmail.com", $subject, $msg);
        if ($sent) {
            $successful = "Thanks! your message is successfully sent to us";
        } else {
            $messageFailed = "Sorry, your message failed to send. Please try again";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>CONTACT US</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" href="css/contatc_us.css">
    <!-- Latest compiled and minified CSS -->
    <!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">-->
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/font-awesome.css">
    <!-- Optional theme -->
    <!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">-->
    <!--<link rel="stylesheet" type="text/css" href="css/font-awesome.css">-->

    <!-- Optional theme -->
    <!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">-->

</head>
<body>

<!--the starting f the nav -->
<div id="myNavbar" class="navabr navbar-default navbar-fixed-top " role="navigation ">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">

                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>

            <a href="" class="navbar-brand">ITCA</a>

        </div>


        <div class="navbar-collapse collapse">


            <ul class="nav navbar-nav navbar-right ">

                <li><a href="home.html">Home</a></li>
                <li><a href="about.html">About us</a></li>
                <li><a href="gallary.html">Gallery</a></li>
                <li><a href="contact.html">Contact</a></li>
                <li><a href="ask.html">Frequently Ask Questions</a></li>
            </ul>
        </div>
    </div><!--end of the nav bar-->
</div>


<!--content-->
<br><br><br><br><br><br><br><br><br><br>
<h1>contact us page</h1>

<div class="container">

    <div class="row">

        <div class="col-md-offset-1 col-md-7">

            <div class="">
                <form action="" method="post" role="form">

                    <div class="form-group">
                        <label>First Name</label>
                        <input type="text" class="form-control" name="firstname" placeholder="Enter First Name"
                               id="f_name" required>
                    </div>

                    <div class="form-group">
                        <label>Last Name</label>
                        <input type="text" class="form-control" name="lastname" placeholder="Enter last name"
                               id="l_name" required>
                    </div>

                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" class="form-control" name="email" placeholder="Enter a valid email address"
                               id="email" required>
                    </div>

                    <div class="form-group">
                        <label>Phone</label>
                        <input type="tel" class="form-control" name="phone" placeholder="Mobile Phone Number"
                               id="phone" required>
                    </div>
		    
		    <div class="form-group">
                        <label>Subject</label>
                        <textarea class="form-control" placeholder="subject" name="subject" id="subject"
                                  required></textarea>
                    </div>

                    <div class="form-group">
                        <label>Message</label>
                        <textarea class="form-control" placeholder="message" name="message" id="message"
                                  required></textarea>
                    </div>
                    <span class="text-warning  " style="color: red"><?= $validatePhone ?></span>
                    <!--                    <input class="btn btn-lg btn-default" name="submit" type="submit" value="Send" id="submit_button">-->
                    <button class="btn btn-success form-control" name="submit">Submit</button>
                    <span class="text-warning  " style="color: red"><?= $messageFailed ?></span>
                    <span class="text-success " style="color: green"><?= $successful ?></span>

                </form>
            </div>

        </div>

        <div class="col-md-4">

            <div class="well">
                <h3>Social</h3>
                <!--<ul>-->
                <a target="_blank" href="#"><i class="fa fa-facebook-square fa-2x"></i></a>
                <a target="_blank" href="#"><i class="fa fa-instagram fa-2x"></i></a>
                <a target="_blank" href="#"><i class="fa fa-linkedin-square fa-2x"></i></a>
                <a target="_blank" href="#"><i class="fa fa-skype fa-2x"></i></a>
                <a target="_blank" href="#"><i class="fa fa-twitter-square fa-2x"></i></a>
                <!--</ul>-->

                <hr>
                <h3>Phone</h3>
                <ul>
                    <li>xxxx</li>
                    <li>xxxx</li>
                    <li>xxxx</li>
                </ul>

                <hr>
                <h3>Email</h3>
                <ul>
                    <li>egfhcgmhfnbs</li>
                    <li>agehjghmghfd</li>
                </ul>

                <hr>
                <h3>Address</h3>
                <ul>
                    <li>brix</li>
                    <li>kombo</li>
                    <li>Banjul, The Gambia</li>
                </ul>

            </div>

        </div>

    </div>


</div>

</div>
<div class="container">
    <div class="row">
        <h2 class="h2">fine us</h2>
        <hr>
        <div class="col-md-12">
            <iframe width="100%" height="450" frameborder="0" style="border:0"
                    src="https://www.google.com/maps/embed/v1/place?q=place_id:ChIJBzivZSmcwg4RKp0Ta0BMSp4&key=AIzaSyAlGReK2MaWJHSnoWEK6kKFTkmJ5sPuOTc"
                    allowfullscreen></iframe>


        </div>
    </div><!--end of the row-->

</div><!--end of the container for the map-->


<div class="cover4">


    <div class="container-fluid">


        <div class="row">
            <div class="social">


                <div class="col-lg-6  col-md-6">
                    <h2>About</h2>
                    <p><i class="fa fa-square-o" aria-hidden="true"></i>About</p>
                    <p><i class="fa fa-square-o" aria-hidden="true"></i>Privacy</p>
                    <p><i class="fa fa-square-o" aria-hidden="true"></i>Terms & Conditions</p>

                </div>

                <div class="col-lg-6 col-md-6 ">
                    <h2>Stay In touch</h2>

                    <i class="fa fa-facebook-official" aria-hidden="true"></i>

                    <i class="fa fa-twitter" aria-hidden="true"></i>
                    <i class="fa fa-linkedin" aria-hidden="true"></i>
                    <i class="fa fa-google-plus" aria-hidden="true"></i>
                    <i class="fa fa-youtube" aria-hidden="true"></i>


                    <br>
                    <input type="email" placeholder="Subscribe fo updates">
                    <button class="btn btn-success">Subscribe</button>


                </div>


            </div><!--end of socila-->
        </div>
    </div>


    <footer>
        @COPY RIGTH ITCA
        <br>
        DEVELOPED BY ITCA WEN DEVELPMENT TEAM 2017
        <div id="footer">

        </div>
    </footer>
</div><!--end of the first cover-->


<!-- Latest compiled and minified JavaScript -->
<script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"
        integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous">

    <
    script
    src = "js/jquery-3.2.1.min.js" ></script>


<script src="js/contact.js"></script>
</body>
</html>
